package com.ht.servlet;
import java.sql.*;


public class ConnectMysql {
	public Connection con = null;
	public Connection getCon(){
		try {    
		    Class.forName("com.mysql.jdbc.Driver");    
		    // 其中test是我们要链接的数据库，user是数库用户名，password是数据库密码。    
		    // 3306是mysql的端口号，一般是这个    
		    // 后面那串长长的参数是为了防止乱码，免去每次都需要在任何语句都加入一条SET NAMES UTF8    
		    String url = "jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=utf8&useOldAliasMetadataBehavior=true";    
		    String user = "root";    
		    String password = "mysql";    
		    con = DriverManager.getConnection(url, user, password);
		    System.out.println("Success!");
//		    return con;
		  
		} catch (Exception e) {
			System.out.println("Insect1_end!");
		    e.printStackTrace();
		}
		return con;
	}
	
	public void closeCon(){
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
