package com.ht.servlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;

public class CheckAccount extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		doGet(req,resp);
	}
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		
		
//		ConnectMysql connectmysql = new ConnectMysql();
//		System.out.println("signup4");
		Connection con=null;
//		
//		System.out.println("signup7");
		HttpSession session = req.getSession();
//		System.out.println("signup5");
		AccountBean account = new AccountBean();
		String username = req.getParameter("username").trim();
		String pwd = req.getParameter("pwd").trim();
//		System.out.println(username);
		account.setPassword(pwd);
		account.setUsername(username);
//		System.out.println("signup3");
//		
//		
//		
//		
		try {
			 Class.forName("com.mysql.jdbc.Driver");    
		    // 其中test是我们要链接的数据库，user是数库用户名，password是数据库密码。    
		    // 3306是mysql的端口号，一般是这个    
		    // 后面那串长长的参数是为了防止乱码，免去每次都需要在任何语句都加入一条SET NAMES UTF8    
		    String url = "jdbc:mysql://localhost:3306/weibo?useUnicode=true&characterEncoding=utf8&useOldAliasMetadataBehavior=true";    
		    String user = "root";    
		    String password = "mysql";    
		    con = DriverManager.getConnection(url, user, password);
//		    System.out.println("username2: ");
		    System.out.println(username + " " + pwd);
		    
		    String select=String.format("select * from userinfo where username=\'%s\'", username);
		    System.out.println(select);
			Statement stmt=con.createStatement(java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,java.sql.ResultSet.CONCUR_READ_ONLY);
//			System.out.println("signup2");
//			int result=stmt.executeUpdate(select);
			System.out.println("result: ");
//			System.out.println("result: "+result);
			ResultSet re = stmt.executeQuery(select);
			if(re.next()){
//				String insert=String.format("insert into userinfo (username,pwd) values (\'%s\',\'%s\')",username,pwd);
//				System.out.println(insert);
//				stmt.execute(insert);
				System.out.println("Yes");
				System.out.println(re.getString(2)+" "+re.getString(3));
//				System.out.println(re.getString(2).equals(username));
//				System.out.println(re.getString(3).equals(pwd));
				if(re.getString(2).equals(username)&&re.getString(3).equals(pwd)){
//					System.out.println(re.getString(2).equals(username));
					String signup_sucess = "index1.jsp";
					resp.sendRedirect(signup_sucess);
					return;
				}
				
			}else{
				System.out.println("No");
				System.out.println(re.getString(2));
				String signup_fail = "fail.jsp";
				resp.sendRedirect(signup_fail);	
				
			}
//			int result=stmt.executeUpdate(search);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
//	  System.out.println(username);
//	  System.out.println(pwd);
//		String login_fail = "fail.jsp";
//		resp.sendRedirect(login_fail);
//		return;
		return;
	}
}